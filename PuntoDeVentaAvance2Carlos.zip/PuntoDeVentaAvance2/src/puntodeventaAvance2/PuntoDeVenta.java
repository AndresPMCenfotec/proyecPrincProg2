//Sistema de punto de venta
//Segundo avance
//Estudiantes:
//Andrés Jossue Pizarro Mendez
//Carlos Roberto López Arce
//Marco Vinicio Soto Agüero
package puntodeventaAvance2;

import javax.swing.JOptionPane;

public class PuntoDeVenta {

    // Capacidad máxima del inventario y arreglos paralelos por SKU
    private static int maxProductos = 100;
    private static String[] skus = new String[maxProductos];
    private static String[] nombres = new String[maxProductos];
    private static double[] costosBase = new double[maxProductos];
    private static int[] stocks = new int[maxProductos];
    private static int[] porcentajesUtilidad = new int[maxProductos];
    private static int[] porcentajesImpuesto = new int[maxProductos];
    private static int[] multiplosRedondeo = new int[maxProductos];
    private static double[] subtotalesReales = new double[maxProductos];
    private static double[] impuestosReales = new double[maxProductos];
    private static double[] utilidadesReales = new double[maxProductos];
    private static double[] preciosAbsolutos = new double[maxProductos];

    // Variables globales de control
    private static int cantidadProductos = 0;
    private static double totalVentasAcumulado = 0.0;

    // Métodos auxiliares de entrada en camelCase con validación
    private static String strShowInputDialog(String mensaje) {
        String entrada = JOptionPane.showInputDialog(null, mensaje);
        if (entrada == null) {
            return "";
        }
        return entrada.trim();
    }

    private static int intShowInputDialog(String mensaje) {
        int valor = 0;
        boolean valido = false;
        while (!valido) {
            String entrada = JOptionPane.showInputDialog(null, mensaje);
            if (entrada == null) {
                return -1;
            }
            try {
                valor = Integer.parseInt(entrada.trim());
                if (valor >= 0) {
                    valido = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Error: Debe ingresar un número entero positivo.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un valor numérico entero válido.");
            }
        }
        return valor;
    }

    private static double doubleShowInputDialog(String mensaje) {
        double valor = 0.0;
        boolean valido = false;
        while (!valido) {
            String entrada = JOptionPane.showInputDialog(null, mensaje);
            if (entrada == null) {
                return -1.0;
            }
            try {
                valor = Double.parseDouble(entrada.trim());
                if (valor >= 0) {
                    valido = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Error: Debe ingresar un monto positivo.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un valor numérico válido.");
            }
        }
        return valor;
    }

    // Busca la posición de un producto en los arreglos mediante su SKU (-1 si no existe)
    private static int buscarIndicePorSku(String skuBuscado) {
        for (int i = 0; i < cantidadProductos; i++) {
            if (skus[i].equalsIgnoreCase(skuBuscado)) {
                return i;
            }
        }
        return -1;
    }

    // Recalcula precio redondeado, subtotal real, IVA real y utilidad real para un índice
    private static void recalcularPreciosProducto(int indice) {
        double subtotalTeorico = costosBase[indice] * (1 + ((double) porcentajesUtilidad[indice] / 100));
        double impuestoTeorico = subtotalTeorico * ((double) porcentajesImpuesto[indice] / 100);
        double precioRedondeado = Math.ceil((subtotalTeorico + impuestoTeorico) / multiplosRedondeo[indice]) * multiplosRedondeo[indice];

        subtotalesReales[indice] = precioRedondeado / (1 + ((double) porcentajesImpuesto[indice] / 100));
        impuestosReales[indice] = subtotalesReales[indice] * ((double) porcentajesImpuesto[indice] / 100);
        utilidadesReales[indice] = subtotalesReales[indice] - costosBase[indice];
        preciosAbsolutos[indice] = precioRedondeado;
    }

    // Opción 1: Registro de nuevo producto asociado a su SKU
    private static void registrarProducto() {
        if (cantidadProductos >= maxProductos) {
            JOptionPane.showMessageDialog(null, "El catálogo ha alcanzado su capacidad máxima de productos.");
            return;
        }

        String skuNuevo = strShowInputDialog("Ingrese el SKU\nSKU sugerido (MTC-0001 o MTC-CAT-PRES)").toUpperCase();
        if (skuNuevo.isEmpty()) {
            return;
        }

        if (buscarIndicePorSku(skuNuevo) != -1) {
            JOptionPane.showMessageDialog(null, "Error: Ya existe un producto registrado con el SKU " + skuNuevo + ".");
            return;
        }

        String nombreNuevo = strShowInputDialog("Agregue el nombre del producto");
        if (nombreNuevo.isEmpty()) {
            return;
        }

        double costoBaseNuevo = doubleShowInputDialog("¿Cuál es el costo base (¢)?");
        if (costoBaseNuevo < 0) {
            return;
        }

        int porcentajeUtilidadNuevo = intShowInputDialog("Ingrese el porcentaje de utilidad (%)");
        if (porcentajeUtilidadNuevo < 0) {
            return;
        }

        int porcentajeImpuestoNuevo = intShowInputDialog("Ingrese el porcentaje de impuesto \"IVA\" (%)");
        if (porcentajeImpuestoNuevo < 0) {
            return;
        }

        int multiploRedondeoNuevo = intShowInputDialog("¿Cuál es el múltiplo de redondeo?");
        if (multiploRedondeoNuevo <= 0) {
            JOptionPane.showMessageDialog(null, "Error: El múltiplo de redondeo debe ser mayor a 0.");
            return;
        }

        skus[cantidadProductos] = skuNuevo;
        nombres[cantidadProductos] = nombreNuevo;
        costosBase[cantidadProductos] = costoBaseNuevo;
        stocks[cantidadProductos] = 0;
        porcentajesUtilidad[cantidadProductos] = porcentajeUtilidadNuevo;
        porcentajesImpuesto[cantidadProductos] = porcentajeImpuestoNuevo;
        multiplosRedondeo[cantidadProductos] = multiploRedondeoNuevo;

        recalcularPreciosProducto(cantidadProductos);

        String fichaProducto = String.format(
                "Producto registrado exitosamente\n\nSKU: %s\nNombre: %s\nStock inicial: %d unidades\n\nCosto base: ¢%.2f\nUtilidad real (%d%%): ¢%.2f\nSubtotal: ¢%.2f + IVA\nImpuesto real (%d%%): ¢%.2f\nMúltiplo de redondeo: %d\nPrecio absoluto: ¢%.2f IVAI",
                skus[cantidadProductos],
                nombres[cantidadProductos],
                stocks[cantidadProductos],
                costosBase[cantidadProductos],
                porcentajesUtilidad[cantidadProductos],
                utilidadesReales[cantidadProductos],
                subtotalesReales[cantidadProductos],
                porcentajesImpuesto[cantidadProductos],
                impuestosReales[cantidadProductos],
                multiplosRedondeo[cantidadProductos],
                preciosAbsolutos[cantidadProductos]);

        JOptionPane.showMessageDialog(null, fichaProducto);
        cantidadProductos++;
    }

    // Opción 2: Espacio modular para la parte de Carlos
    private static void procesoDeCompra() {

        // Solicitar SKU del producto
        String skuBuscado = strShowInputDialog(
                "Ingrese el SKU del producto que desea comprar:"
        ).toUpperCase();

        if (skuBuscado.isEmpty()) {
            return;
        }

        // Buscar producto en el inventario
        int indice = buscarIndicePorSku(skuBuscado);

        if (indice == -1) {
            JOptionPane.showMessageDialog(
                    null,
                    "No se encontró ningún producto con el SKU: " + skuBuscado
            );
            return;
        }

        // Solicitar cantidad comprada
        int cantidadComprada = intShowInputDialog(
                "Producto: " + nombres[indice]
                + "\nStock actual: " + stocks[indice]
                + "\n\nIngrese la cantidad comprada:"
        );

        if (cantidadComprada <= 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "La cantidad comprada debe ser mayor que cero."
            );
            return;
        }

        // Solicitar costo unitario de compra
        double costoCompra = doubleShowInputDialog(
                "Producto: " + nombres[indice]
                + "\nCantidad comprada: " + cantidadComprada
                + "\n\nIngrese el costo unitario cobrado por el proveedor:"
        );

        if (costoCompra <= 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "El costo de compra debe ser mayor que cero."
            );
            return;
        }

        // Guardar datos anteriores
        int stockAnterior = stocks[indice];
        double costoPromedioAnterior = costosBase[indice];

        // Calcular nuevo costo promedio ponderado
        double nuevoCostoPromedio
                = ((stockAnterior * costoPromedioAnterior)
                + (cantidadComprada * costoCompra))
                / (stockAnterior + cantidadComprada);

        // Actualizar inventario
        stocks[indice] = stockAnterior + cantidadComprada;
        costosBase[indice] = nuevoCostoPromedio;

        // Recalcular precios, impuestos y utilidad
        recalcularPreciosProducto(indice);

        // Calcular total de la compra
        double totalCompra = cantidadComprada * costoCompra;

        // Imprimir tiquete en consola
        imprimirTiqueteCompra(
                skuBuscado,
                nombres[indice],
                cantidadComprada,
                costoCompra,
                totalCompra,
                stockAnterior,
                stocks[indice],
                costoPromedioAnterior,
                nuevoCostoPromedio
        );

        // Mostrar confirmación
        JOptionPane.showMessageDialog(
                null,
                String.format(
                        "Compra registrada exitosamente.\n\n"
                        + "Producto: %s\n"
                        + "SKU: %s\n"
                        + "Cantidad comprada: %d\n"
                        + "Nuevo stock: %d unidades\n"
                        + "Nuevo costo promedio: ¢%.2f",
                        nombres[indice],
                        skuBuscado,
                        cantidadComprada,
                        stocks[indice],
                        costosBase[indice]
                )
        );
    }
    
    //Impresión de tiquete de compra
    private static void imprimirTiqueteCompra(
            String sku,
            String nombre,
            int cantidad,
            double costoCompra,
            double totalCompra,
            int stockAnterior,
            int stockNuevo,
            double costoAnterior,
            double costoNuevo) {

        System.out.println();
        System.out.println("==============================================");
        System.out.println("          MI TIENDITA COMPAÑERA");
        System.out.println("              TIQUETE DE COMPRA");
        System.out.println("==============================================");

        System.out.printf("SKU:                  %s%n", sku);
        System.out.printf("Producto:             %s%n", nombre);

        System.out.println("----------------------------------------------");

        System.out.printf("Cantidad comprada:    %d unidades%n", cantidad);
        System.out.printf("Costo unitario:       ¢%.2f%n", costoCompra);
        System.out.printf("Total de compra:      ¢%.2f%n", totalCompra);

        System.out.println("----------------------------------------------");

        System.out.printf("Stock anterior:       %d unidades%n", stockAnterior);
        System.out.printf("Stock actualizado:    %d unidades%n", stockNuevo);

        System.out.printf("Costo promedio anterior: ¢%.2f%n", costoAnterior);
        System.out.printf("Costo promedio nuevo:    ¢%.2f%n", costoNuevo);

        System.out.println("==============================================");
        System.out.println("           FIN DEL COMPROBANTE");
        System.out.println("==============================================");
        System.out.println();
    }

    // Opción 3: Espacio modular para la parte de Marco
    private static void registrarSalidaVenta() {
        JOptionPane.showMessageDialog(null, "Módulo de Salida por Venta pendiente de integrar.");
    }

    // Opción 4: Espacio modular para la parte de Marco
    private static void registrarSalidaDanado() {
        JOptionPane.showMessageDialog(null, "Módulo de Salida por Producto Dañado pendiente de integrar.");
    }

    // Menú principal iterativo
    public static void main(String[] args) {
        int opcion = 0;
        String menuPrincipal = "=== MI TIENDITA COMPAÑERA ===\n\n"
                + "1. Registrar Producto (asociando SKU)\n"
                + "2. Proceso de Compra / Entrada de Inventario\n"
                + "3. Registrar Salida por Venta\n"
                + "4. Registrar Salida por Producto Dañado\n"
                + "5. Salir\n\n"
                + "Seleccione una opción:";

        do {
            String entrada = JOptionPane.showInputDialog(null, menuPrincipal);

            if (entrada == null) {
                opcion = 5;
            } else {
                try {
                    opcion = Integer.parseInt(entrada.trim());
                } catch (NumberFormatException e) {
                    opcion = 0;
                }
            }

            switch (opcion) {
                case 1:
                    registrarProducto();
                    break;
                case 2:
                    procesoDeCompra();
                    break;
                case 3:
                    registrarSalidaVenta();
                    break;
                case 4:
                    registrarSalidaDanado();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema Mi Tiendita Compañera.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Por favor seleccione un número del 1 al 5.");
                    break;
            }
        } while (opcion != 5);
    }
}
