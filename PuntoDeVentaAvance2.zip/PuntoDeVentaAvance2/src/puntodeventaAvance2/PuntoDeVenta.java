//Sistema de punto de venta
//Segundo avance
//Estudiantes:
//Andrés Jossue Pizarro Mendez
//Carlos Roberto López Arce
//Marco Vinicio Soto Agüero
package puntodeventaAvance2;

import javax.swing.JOptionPane;

public class PuntoDeVenta {

    // Capacidad máxima del inventario y arreglos paralelos por SKU
    private static int maxProductos = 100;
    private static String[] skus = new String[maxProductos];
    private static String[] nombres = new String[maxProductos];
    private static double[] costosBase = new double[maxProductos];
    private static int[] stocks = new int[maxProductos];
    private static int[] porcentajesUtilidad = new int[maxProductos];
    private static int[] porcentajesImpuesto = new int[maxProductos];
    private static int[] multiplosRedondeo = new int[maxProductos];
    private static double[] subtotalesReales = new double[maxProductos];
    private static double[] impuestosReales = new double[maxProductos];
    private static double[] utilidadesReales = new double[maxProductos];
    private static double[] preciosAbsolutos = new double[maxProductos];

    // Variables globales de control
    private static int cantidadProductos = 0;
    private static double totalVentasAcumulado = 0.0;

    // Métodos auxiliares de entrada en camelCase con validación
    private static String strShowInputDialog(String mensaje) {
        String entrada = JOptionPane.showInputDialog(null, mensaje);
        if (entrada == null) {
            return "";
        }
        return entrada.trim();
    }

    private static int intShowInputDialog(String mensaje) {
        int valor = 0;
        boolean valido = false;
        while (!valido) {
            String entrada = JOptionPane.showInputDialog(null, mensaje);
            if (entrada == null) {
                return -1;
            }
            try {
                valor = Integer.parseInt(entrada.trim());
                if (valor >= 0) {
                    valido = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Error: Debe ingresar un número entero positivo.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un valor numérico entero válido.");
            }
        }
        return valor;
    }

    private static double doubleShowInputDialog(String mensaje) {
        double valor = 0.0;
        boolean valido = false;
        while (!valido) {
            String entrada = JOptionPane.showInputDialog(null, mensaje);
            if (entrada == null) {
                return -1.0;
            }
            try {
                valor = Double.parseDouble(entrada.trim());
                if (valor >= 0) {
                    valido = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Error: Debe ingresar un monto positivo.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un valor numérico válido.");
            }
        }
        return valor;
    }

    // Busca la posición de un producto en los arreglos mediante su SKU (-1 si no existe)
    private static int buscarIndicePorSku(String skuBuscado) {
        for (int i = 0; i < cantidadProductos; i++) {
            if (skus[i].equalsIgnoreCase(skuBuscado)) {
                return i;
            }
        }
        return -1;
    }

    // Recalcula precio redondeado, subtotal real, IVA real y utilidad real (fórmula exacta Avance 1)
    private static void recalcularPreciosProducto(int indice) {
        double subtotalTeorico = costosBase[indice] / (1 - ((double) porcentajesUtilidad[indice] / 100));
        double impuestoTeorico = subtotalTeorico * ((double) porcentajesImpuesto[indice] / 100);
        double precioRedondeado = Math.ceil((subtotalTeorico + impuestoTeorico) / multiplosRedondeo[indice]) * multiplosRedondeo[indice];

        subtotalesReales[indice] = precioRedondeado / (1 + ((double) porcentajesImpuesto[indice] / 100));
        impuestosReales[indice] = subtotalesReales[indice] * ((double) porcentajesImpuesto[indice] / 100);
        utilidadesReales[indice] = subtotalesReales[indice] - costosBase[indice];
        preciosAbsolutos[indice] = precioRedondeado;
    }

    // Opción 1: Registro de nuevo producto asociado a su SKU
    private static void registrarProducto() {
        if (cantidadProductos >= maxProductos) {
            JOptionPane.showMessageDialog(null, "El catálogo ha alcanzado su capacidad máxima de productos.");
            return;
        }

        String skuNuevo = strShowInputDialog("Ingrese el SKU\nSKU sugerido (MTC-0001 o MTC-CAT-PRES)").toUpperCase();
        if (skuNuevo.isEmpty()) {
            return;
        }

        if (buscarIndicePorSku(skuNuevo) != -1) {
            JOptionPane.showMessageDialog(null, "Error: Ya existe un producto registrado con el SKU " + skuNuevo + ".");
            return;
        }

        String nombreNuevo = strShowInputDialog("Agregue el nombre del producto");
        if (nombreNuevo.isEmpty()) {
            return;
        }

        double costoBaseNuevo = doubleShowInputDialog("¿Cuál es el costo base (¢)?");
        if (costoBaseNuevo < 0) {
            return;
        }

        int porcentajeUtilidadNuevo = intShowInputDialog("Ingrese el porcentaje de utilidad (%)");
        if (porcentajeUtilidadNuevo < 0) {
            return;
        }

        int porcentajeImpuestoNuevo = intShowInputDialog("Ingrese el porcentaje de impuesto \"IVA\" (%)");
        if (porcentajeImpuestoNuevo < 0) {
            return;
        }

        int multiploRedondeoNuevo = intShowInputDialog("¿Cuál es el múltiplo de redondeo?");
        if (multiploRedondeoNuevo <= 0) {
            JOptionPane.showMessageDialog(null, "Error: El múltiplo de redondeo debe ser mayor a 0.");
            return;
        }

        skus[cantidadProductos] = skuNuevo;
        nombres[cantidadProductos] = nombreNuevo;
        costosBase[cantidadProductos] = costoBaseNuevo;
        stocks[cantidadProductos] = 0;
        porcentajesUtilidad[cantidadProductos] = porcentajeUtilidadNuevo;
        porcentajesImpuesto[cantidadProductos] = porcentajeImpuestoNuevo;
        multiplosRedondeo[cantidadProductos] = multiploRedondeoNuevo;

        recalcularPreciosProducto(cantidadProductos);

        String fichaProducto = String.format(
                "Producto registrado exitosamente\n\nSKU: %s\nNombre: %s\nStock inicial: %d unidades\n\nCosto base: ¢%.2f\nUtilidad real (%d%%): ¢%.2f\nSubtotal: ¢%.2f + IVA\nImpuesto real (%d%%): ¢%.2f\nMúltiplo de redondeo: %d\nPrecio absoluto: ¢%.2f IVAI",
                skus[cantidadProductos],
                nombres[cantidadProductos],
                stocks[cantidadProductos],
                costosBase[cantidadProductos],
                porcentajesUtilidad[cantidadProductos],
                utilidadesReales[cantidadProductos],
                subtotalesReales[cantidadProductos],
                porcentajesImpuesto[cantidadProductos],
                impuestosReales[cantidadProductos],
                multiplosRedondeo[cantidadProductos],
                preciosAbsolutos[cantidadProductos]);

        JOptionPane.showMessageDialog(null, fichaProducto);
        cantidadProductos++;
    }

    // Opción 2: Proceso de Compra / Entrada de Inventario
    private static void procesoDeCompra() {
        String skuBuscado = strShowInputDialog("Ingrese el SKU del producto que desea comprar:").toUpperCase();
        if (skuBuscado.isEmpty()) {
            return;
        }

        int indice = buscarIndicePorSku(skuBuscado);
        if (indice == -1) {
            JOptionPane.showMessageDialog(null, "No se encontró ningún producto con el SKU: " + skuBuscado);
            return;
        }

        int cantidadComprada = intShowInputDialog(
                "Producto: " + nombres[indice]
                + "\nStock actual: " + stocks[indice]
                + "\n\nIngrese la cantidad comprada:");
        if (cantidadComprada < 0) {
            return;
        }
        if (cantidadComprada == 0) {
            JOptionPane.showMessageDialog(null, "La cantidad comprada debe ser mayor que cero.");
            return;
        }

        double costoCompra = doubleShowInputDialog(
                "Producto: " + nombres[indice]
                + "\nCantidad comprada: " + cantidadComprada
                + "\n\nIngrese el costo unitario cobrado por el proveedor:");
        if (costoCompra < 0) {
            return;
        }
        if (costoCompra == 0) {
            JOptionPane.showMessageDialog(null, "El costo de compra debe ser mayor que cero.");
            return;
        }

        int stockAnterior = stocks[indice];
        double costoPromedioAnterior = costosBase[indice];

        double nuevoCostoPromedio = ((stockAnterior * costoPromedioAnterior) + (cantidadComprada * costoCompra))
                / (stockAnterior + cantidadComprada);

        stocks[indice] = stockAnterior + cantidadComprada;
        costosBase[indice] = nuevoCostoPromedio;

        recalcularPreciosProducto(indice);

        double totalCompra = cantidadComprada * costoCompra;

        imprimirTiqueteCompra(
                skus[indice],
                nombres[indice],
                cantidadComprada,
                costoCompra,
                totalCompra,
                stockAnterior,
                stocks[indice],
                costoPromedioAnterior,
                nuevoCostoPromedio);

        JOptionPane.showMessageDialog(
                null,
                String.format(
                        "Compra registrada exitosamente.\n\n"
                        + "Producto: %s\n"
                        + "SKU: %s\n"
                        + "Cantidad comprada: %d\n"
                        + "Nuevo stock: %d unidades\n"
                        + "Nuevo costo promedio: ¢%.2f\n"
                        + "Nuevo precio de venta: ¢%.2f IVAI",
                        nombres[indice],
                        skus[indice],
                        cantidadComprada,
                        stocks[indice],
                        costosBase[indice],
                        preciosAbsolutos[indice]));
    }

    // Impresión de tiquete de compra en consola
    private static void imprimirTiqueteCompra(
            String sku,
            String nombre,
            int cantidad,
            double costoCompra,
            double totalCompra,
            int stockAnterior,
            int stockNuevo,
            double costoAnterior,
            double costoNuevo) {

        System.out.println();
        System.out.println("==============================================");
        System.out.println("          MI TIENDITA COMPAÑERA");
        System.out.println("              TIQUETE DE COMPRA");
        System.out.println("==============================================");
        System.out.printf("SKU:                     %s%n", sku);
        System.out.printf("Producto:                %s%n", nombre);
        System.out.println("----------------------------------------------");
        System.out.printf("Cantidad comprada:       %d unidades%n", cantidad);
        System.out.printf("Costo unitario:          ¢%.2f%n", costoCompra);
        System.out.printf("Total de compra:         ¢%.2f%n", totalCompra);
        System.out.println("----------------------------------------------");
        System.out.printf("Stock anterior:          %d unidades%n", stockAnterior);
        System.out.printf("Stock actualizado:       %d unidades%n", stockNuevo);
        System.out.printf("Costo promedio anterior: ¢%.2f%n", costoAnterior);
        System.out.printf("Costo promedio nuevo:    ¢%.2f%n", costoNuevo);
        System.out.println("==============================================");
        System.out.println("            FIN DEL COMPROBANTE");
        System.out.println("==============================================");
        System.out.println();
    }

    // Impresión de tiquete de venta en consola
    private static void impresionVenta(String sku, String nombre, int cantidad, int porcIva, double precioAbs) {
        double precioSinIva = precioAbs / (1 + (porcIva / 100.0));
        double subtotalVenta = precioSinIva * cantidad;
        double totalVenta = precioAbs * cantidad;
        double ivaVenta = totalVenta - subtotalVenta;

        System.out.println("\n==============================================");
        System.out.println("          MI TIENDITA COMPAÑERA");
        System.out.println("              TIQUETE DE VENTA");
        System.out.println("==============================================");
        System.out.printf("SKU:                     %s%n", sku);
        System.out.printf("Producto:                %s%n", nombre);
        System.out.printf("Precio unitario:         ¢%.2f + IVA%n", precioSinIva);
        System.out.println("----------------------------------------------");
        System.out.printf("Cantidad:                %d unidades%n", cantidad);
        System.out.printf("Subtotal:                ¢%.2f%n", subtotalVenta);
        System.out.printf("IVA (%d%%):               ¢%.2f%n", porcIva, ivaVenta);
        System.out.printf("Precio absoluto total:   ¢%.2f%n", totalVenta);
        System.out.println("==============================================");
        System.out.println("            FIN DEL COMPROBANTE");
        System.out.println("==============================================\n");
    }

    // Opción 3: Registrar Salida por Venta
    private static void registrarSalidaVenta() {
        String sku = strShowInputDialog("Ingrese el SKU del producto a vender:").toUpperCase();
        if (sku.isEmpty()) {
            return;
        }

        int indice = buscarIndicePorSku(sku);
        if (indice == -1) {
            JOptionPane.showMessageDialog(null, "El SKU no ha sido encontrado.");
            return;
        }

        if (stocks[indice] == 0) {
            JOptionPane.showMessageDialog(null, "El SKU buscado no cuenta con stock disponible.");
            return;
        }

        String mensaje = String.format(
                "SKU: %s\nDescripción: %s\nPrecio unitario: ¢%.2f IVAI\nStock actual: %d\n\nCantidad de venta:",
                skus[indice], nombres[indice], preciosAbsolutos[indice], stocks[indice]);
        int cantidad = intShowInputDialog(mensaje);
        if (cantidad < 0) {
            return;
        }

        if (cantidad > 0 && cantidad <= stocks[indice]) {
            stocks[indice] -= cantidad;
            double montoVenta = preciosAbsolutos[indice] * cantidad;
            totalVentasAcumulado += montoVenta;

            impresionVenta(skus[indice], nombres[indice], cantidad, porcentajesImpuesto[indice], preciosAbsolutos[indice]);

            JOptionPane.showMessageDialog(null, String.format(
                    "Venta registrada exitosamente.\n\nTotal cobrado: ¢%.2f\nStock restante: %d unidades\nVentas acumuladas en caja: ¢%.2f",
                    montoVenta, stocks[indice], totalVentasAcumulado));
        } else if (cantidad == 0) {
            JOptionPane.showMessageDialog(null, "La cantidad de venta debe ser mayor a 0.");
        } else {
            JOptionPane.showMessageDialog(null, "La cantidad de venta es mayor al stock disponible (" + stocks[indice] + ").");
        }
    }

    // Impresión de comprobante de merma en consola
    private static void comprobanteMerma(String sku, String nombre, int cantidadDesc, double costoPromedio, String motivo) {
        double perdidaTotal = cantidadDesc * costoPromedio;

        System.out.println("\n==============================================");
        System.out.println("          MI TIENDITA COMPAÑERA");
        System.out.println("          COMPROBANTE DE MERMA");
        System.out.println("==============================================");
        System.out.printf("SKU:                     %s%n", sku);
        System.out.printf("Producto:                %s%n", nombre);
        System.out.println("----------------------------------------------");
        System.out.printf("Cantidad dañada:         -%d unidades%n", cantidadDesc);
        System.out.printf("Costo promedio unitario: ¢%.2f%n", costoPromedio);
        System.out.printf("Pérdida registrada:      ¢%.2f%n", perdidaTotal);
        System.out.printf("Motivo:                  %s%n", motivo);
        System.out.println("==============================================");
        System.out.println("            FIN DEL COMPROBANTE");
        System.out.println("==============================================\n");
    }

    // Opción 4: Registrar Salida por Producto Dañado (Merma)
    private static void registrarSalidaDanado() {
        String sku = strShowInputDialog("Ingrese el SKU del producto dañado:").toUpperCase();
        if (sku.isEmpty()) {
            return;
        }

        int indice = buscarIndicePorSku(sku);
        if (indice == -1) {
            JOptionPane.showMessageDialog(null, "El SKU no ha sido encontrado.");
            return;
        }

        if (stocks[indice] == 0) {
            JOptionPane.showMessageDialog(null, "El SKU buscado no cuenta con stock disponible.");
            return;
        }

        String mensaje = String.format(
                "SKU: %s\nDescripción: %s\nStock actual: %d\n\nCantidad dañada:",
                skus[indice], nombres[indice], stocks[indice]);
        int cantidad = intShowInputDialog(mensaje);
        if (cantidad < 0) {
            return;
        }

        if (cantidad > 0 && cantidad <= stocks[indice]) {
            String motivo = strShowInputDialog("Ingrese el motivo del daño o merma (ej. Empaque roto, Producto vencido):");
            if (motivo.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: Debe ingresar una justificación obligatoria para registrar la merma.");
                return;
            }

            stocks[indice] -= cantidad;
            comprobanteMerma(skus[indice], nombres[indice], cantidad, costosBase[indice], motivo);

            JOptionPane.showMessageDialog(null, String.format(
                    "Baja por merma registrada.\n\nUnidades descontadas: %d\nPérdida al costo: ¢%.2f\nStock restante: %d unidades",
                    cantidad, (cantidad * costosBase[indice]), stocks[indice]));
        } else if (cantidad == 0) {
            JOptionPane.showMessageDialog(null, "La cantidad dañada debe ser mayor a 0.");
        } else {
            JOptionPane.showMessageDialog(null, "La cantidad dañada es mayor al stock disponible (" + stocks[indice] + ").");
        }
    }

    // Menú principal iterativo
    public static void main(String[] args) {
        int opcion = 0;
        String menuPrincipal = "=== MI TIENDITA COMPAÑERA ===\n\n"
                + "1. Registrar Producto (asociando SKU)\n"
                + "2. Proceso de Compra / Entrada de Inventario\n"
                + "3. Registrar Salida por Venta\n"
                + "4. Registrar Salida por Producto Dañado\n"
                + "5. Salir\n\n"
                + "Seleccione una opción:";

        do {
            String entrada = JOptionPane.showInputDialog(null, menuPrincipal);

            if (entrada == null) {
                opcion = 5;
            } else {
                try {
                    opcion = Integer.parseInt(entrada.trim());
                } catch (NumberFormatException e) {
                    opcion = 0;
                }
            }

            switch (opcion) {
                case 1:
                    registrarProducto();
                    break;
                case 2:
                    procesoDeCompra();
                    break;
                case 3:
                    registrarSalidaVenta();
                    break;
                case 4:
                    registrarSalidaDanado();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, String.format(
                            "Saliendo del sistema Mi Tiendita Compañera.\nTotal acumulado en ventas: ¢%.2f",
                            totalVentasAcumulado));
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Por favor seleccione un número del 1 al 5.");
                    break;
            }
        } while (opcion != 5);
    }
}